import { redirect } from 'next/navigation'
import { getGroups } from '@/lib/db'

export const dynamic = 'force-dynamic'

// /pay opens the payment page for the first group.
export default async function PayIndex() {
  const groups = await getGroups()
  redirect(groups[0] ? `/pay/${groups[0].id}` : '/')
}
