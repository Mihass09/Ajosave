import { notFound } from 'next/navigation'
import PayForm from '@/components/PayForm'
import { getGroupDetail } from '@/lib/db'

export const dynamic = 'force-dynamic'

export default async function PayPage({ params }: { params: { id: string } }) {
  const d = await getGroupDetail(params.id)
  if (!d) notFound()
  return <PayForm groupId={d.group.id} groupName={d.group.name} amount={d.group.contribution} />
}
