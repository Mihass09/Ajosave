import Link from 'next/link'
import Stripe from 'stripe'
import { naira } from '@/lib/data'
import { getGroupDetail, recordPayment } from '@/lib/db'

export const dynamic = 'force-dynamic'

type SP = { reference?: string; trxref?: string; session_id?: string; demo?: string; group?: string; method?: string }
type Result = { ok: boolean; total?: number; method?: string; groupId?: string; message?: string }

async function confirm(sp: SP): Promise<Result> {
  try {
    if (sp.demo && sp.group) {
      const d = await getGroupDetail(sp.group)
      return { ok: true, total: d ? d.group.contribution + 100 : undefined, method: sp.method, groupId: sp.group }
    }
    const ref = sp.reference ?? sp.trxref
    if (ref) {
      const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(ref)}`, {
        headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` }, cache: 'no-store',
      })
      const j = await r.json()
      if (!j.status || j.data.status !== 'success') return { ok: false, message: 'Paystack did not confirm this payment.' }
      const m = j.data.metadata
      await recordPayment({ groupId: m.group_id, userId: m.user_id, amount: Number(m.amount), fee: Number(m.fee), method: 'paystack', reference: ref })
      return { ok: true, total: j.data.amount / 100, method: 'Paystack', groupId: m.group_id }
    }
    if (sp.session_id) {
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)
      const s = await stripe.checkout.sessions.retrieve(sp.session_id)
      if (s.payment_status !== 'paid') return { ok: false, message: 'Stripe did not confirm this payment.' }
      const m = s.metadata!
      await recordPayment({ groupId: m.group_id, userId: m.user_id, amount: Number(m.amount), fee: Number(m.fee), method: 'stripe', reference: m.reference })
      return { ok: true, total: (s.amount_total ?? 0) / 100, method: 'Stripe', groupId: m.group_id }
    }
    return { ok: false, message: 'No payment found to confirm.' }
  } catch (e: any) {
    return { ok: false, message: e.message ?? 'Could not confirm the payment.' }
  }
}

export default async function Complete({ searchParams }: { searchParams: SP }) {
  const r = await confirm(searchParams)
  return (
    <div className="px-5 pt-24 text-center">
      <span className={`mx-auto grid h-20 w-20 place-items-center rounded-full text-3xl font-bold ${r.ok ? 'bg-brand text-brand-ink' : 'bg-red-100 text-red-700'}`}>
        {r.ok ? '✓' : '!'}
      </span>
      <h1 className="mt-6 text-2xl font-bold">{r.ok ? 'Payment received' : 'Payment not confirmed'}</h1>
      <p className="mt-2 text-slate-500">
        {r.ok ? `${r.total ? naira(r.total) : 'Your payment'} was paid with ${r.method}.` : r.message}
      </p>
      <Link href={r.groupId ? `/groups/${r.groupId}` : '/'} className="mt-8 block rounded-2xl bg-brand py-4 font-bold text-brand-ink">
        Back to group
      </Link>
    </div>
  )
}
