import Link from 'next/link'
import { notFound } from 'next/navigation'
import StatusTag from '@/components/StatusTag'
import { initials, naira, nairaShort, pct } from '@/lib/data'
import { getGroupDetail } from '@/lib/db'

export const dynamic = 'force-dynamic'

export default async function GroupPage({ params }: { params: { id: string } }) {
  const detail = await getGroupDetail(params.id)
  if (!detail) notFound()
  const g = detail.group
  const list = detail.members
  const p = pct(g)
  const r = 64
  const c = 2 * Math.PI * r

  return (
    <div className="px-5 pb-28 pt-6">
      <Link href="/" className="text-sm font-medium text-slate-500">Back</Link>
      <div className="mt-3 flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">{g.name}</h1>
        <span className="rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-900">{g.status}</span>
      </div>

      <section className="mt-6 flex flex-col items-center rounded-[28px] bg-brand-soft px-6 py-8">
        <div className="relative h-44 w-44">
          <svg viewBox="0 0 160 160" className="h-full w-full -rotate-90" role="img" aria-label={`${p}% saved`}>
            <circle cx="80" cy="80" r={r} fill="none" stroke="#dcfce7" strokeWidth="14" />
            <circle cx="80" cy="80" r={r} fill="none" stroke="#22c55e" strokeWidth="14" strokeLinecap="round"
              strokeDasharray={c} strokeDashoffset={c * (1 - p / 100)} />
          </svg>
          <div className="absolute inset-0 grid place-items-center text-center">
            <div>
              <p className="text-4xl font-extrabold text-brand-ink">{p}%</p>
              <p className="text-xs text-slate-500">of target</p>
            </div>
          </div>
        </div>
        <p className="mt-4 text-lg font-bold">{nairaShort(g.saved)} <span className="font-medium text-slate-500">of {nairaShort(g.target)}</span></p>
        <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-green-100">
          <div className="h-full rounded-full bg-brand" style={{ width: `${p}%` }} />
        </div>
        <p className="mt-3 text-sm text-slate-500">{g.members} members, {naira(g.contribution)} each round</p>
      </section>

      <section className="mt-6 flex items-center gap-4 rounded-2xl border border-slate-100 p-4">
        <span className="grid h-12 w-12 place-items-center rounded-full bg-brand font-bold text-brand-ink">{initials(g.nextPayer)}</span>
        <div className="flex-1">
          <p className="text-sm text-slate-500">Pays next</p>
          <p className="font-semibold">{g.nextPayer}</p>
        </div>
        <p className="text-sm font-semibold">{g.nextDue}</p>
      </section>

      <section className="mt-8">
        <h2 className="text-lg font-bold">Members</h2>
        <ul className="mt-2 divide-y divide-slate-100">
          {list.map((m) => (
            <li key={m.name} className="flex items-center gap-3 py-3.5">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-slate-100 text-sm font-bold text-slate-700">{initials(m.name)}</span>
              <span className="flex-1">
                <span className="block font-medium">{m.name}</span>
                <span className="block text-xs text-slate-500">Last paid {m.lastPaid}</span>
              </span>
              <StatusTag status={m.status} />
            </li>
          ))}
        </ul>
      </section>

      <div className="fixed bottom-0 left-1/2 w-full max-w-md -translate-x-1/2 bg-white/90 p-4 backdrop-blur">
        <Link href={`/pay/${g.id}`} className="block rounded-2xl bg-brand py-4 text-center text-base font-bold text-brand-ink">
          Pay now
        </Link>
      </div>
    </div>
  )
}
