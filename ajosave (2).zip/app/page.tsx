import Link from 'next/link'
import { initials, naira, pct } from '@/lib/data'
import { getCurrentUser, getGroups } from '@/lib/db'

export const dynamic = 'force-dynamic'

export default async function Home() {
  const [groups, user] = await Promise.all([getGroups(), getCurrentUser()])
  const total = groups.reduce((s, g) => s + g.saved, 0)
  return (
    <div className="px-5 pb-10 pt-8">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-500">Welcome back</p>
          <h1 className="text-2xl font-bold tracking-tight">{user.name}</h1>
        </div>
        <span className="grid h-11 w-11 place-items-center rounded-full bg-brand-soft text-lg font-bold text-brand-ink">
          {user.name[0]}
        </span>
      </header>

      <section className="mt-6 rounded-[28px] bg-brand p-6 text-brand-ink">
        <p className="text-sm font-medium">Total saved</p>
        <p className="mt-1 text-[44px] font-extrabold leading-none tracking-tight">{naira(total)}</p>
        <p className="mt-4 text-sm font-medium">Across {groups.length} active groups</p>
      </section>

      <section className="mt-8">
        <h2 className="text-lg font-bold">Your groups</h2>
        <ul className="mt-2 divide-y divide-slate-100">
          {groups.map((g) => (
            <li key={g.id}>
              <Link href={`/groups/${g.id}`} className="flex items-center gap-4 py-4">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-brand-soft font-bold text-brand-ink">
                  {initials(g.name)}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{g.name}</span>
                  <span className="block text-sm text-slate-500">Next due {g.nextDue}</span>
                  <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-slate-100">
                    <span className="block h-full rounded-full bg-brand" style={{ width: `${pct(g)}%` }} />
                  </span>
                </span>
                <span className="text-right">
                  <span className="rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-900">{g.status}</span>
                  <span className="mt-2 block text-sm font-semibold">{naira(g.contribution)}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
