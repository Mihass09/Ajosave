import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { FEE } from '@/lib/data'
import { getCurrentUser, getGroupDetail } from '@/lib/db'

export async function POST(req: Request) {
  const { groupId, method } = await req.json()
  const detail = await getGroupDetail(groupId)
  if (!detail) return NextResponse.json({ error: 'Group not found' }, { status: 404 })

  const user = await getCurrentUser()
  const amount = detail.group.contribution
  const total = amount + FEE
  const origin = new URL(req.url).origin
  const reference = `ajo_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
  const meta = { group_id: groupId, user_id: user.id, amount: String(amount), fee: String(FEE), reference }

  try {
    if (method === 'paystack') {
      if (!process.env.PAYSTACK_SECRET_KEY) return NextResponse.json({ url: `${origin}/pay/complete?demo=1&group=${groupId}&method=Paystack` })
      const r = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: user.email, amount: total * 100, currency: 'NGN', reference, callback_url: `${origin}/pay/complete`, metadata: meta }),
      })
      const j = await r.json()
      if (!j.status) throw new Error(j.message)
      return NextResponse.json({ url: j.data.authorization_url })
    }

    if (method === 'stripe') {
      if (!process.env.STRIPE_SECRET_KEY) return NextResponse.json({ url: `${origin}/pay/complete?demo=1&group=${groupId}&method=Stripe` })
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)
      const s = await stripe.checkout.sessions.create({
        mode: 'payment',
        customer_email: user.email,
        line_items: [{ quantity: 1, price_data: { currency: 'ngn', unit_amount: total * 100, product_data: { name: `${detail.group.name} contribution and fee` } } }],
        metadata: meta,
        success_url: `${origin}/pay/complete?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${origin}/pay/${groupId}`,
      })
      return NextResponse.json({ url: s.url })
    }

    return NextResponse.json({ error: 'Unknown payment method' }, { status: 400 })
  } catch (e: any) {
    return NextResponse.json({ error: e.message ?? 'Checkout failed' }, { status: 500 })
  }
}
