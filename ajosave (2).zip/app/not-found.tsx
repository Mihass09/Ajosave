import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="px-5 pt-24 text-center">
      <h1 className="text-2xl font-bold">We could not find that page</h1>
      <p className="mt-2 text-slate-500">The group may have been removed.</p>
      <Link href="/" className="mt-8 block rounded-2xl bg-brand py-4 font-bold text-brand-ink">Back to home</Link>
    </div>
  )
}
