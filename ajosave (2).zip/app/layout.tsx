import './globals.css'
import type { Metadata, Viewport } from 'next'
import { Bricolage_Grotesque } from 'next/font/google'

const font = Bricolage_Grotesque({ subsets: ['latin'], variable: '--font-sans' })

export const metadata: Metadata = {
  title: 'AjoSave',
  description: 'Save together. Reach your goals faster.',
}
export const viewport: Viewport = { themeColor: '#22c55e', width: 'device-width', initialScale: 1 }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${font.variable} bg-slate-100 font-sans text-slate-900 antialiased`}>
        <main className="relative mx-auto min-h-screen max-w-md bg-white shadow-sm">{children}</main>
      </body>
    </html>
  )
}
