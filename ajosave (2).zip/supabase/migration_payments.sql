-- Only needed if you already ran the first schema.sql
alter table payments add column if not exists user_id uuid references users(id);
alter table payments add column if not exists reference text unique;
