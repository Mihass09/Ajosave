create extension if not exists "pgcrypto";

create table users (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text unique,
  email text unique,
  balance numeric(14,2) not null default 0
);

create table groups (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  target_amount numeric(14,2) not null,
  contribution_amount numeric(14,2) not null,
  members_count int not null default 0,
  next_due date
);

create table group_members (
  group_id uuid references groups(id) on delete cascade,
  user_id uuid references users(id) on delete cascade,
  status text not null default 'Pending' check (status in ('Paid','Due','Pending')),
  last_paid date,
  primary key (group_id, user_id)
);

create table payments (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references groups(id) on delete cascade,
  amount numeric(14,2) not null,
  fee numeric(14,2) not null default 100,
  total numeric(14,2) not null,
  method text not null check (method in ('paystack','stripe')),
  user_id uuid references users(id),
  reference text unique,
  created_at timestamptz not null default now()
);

-- Turn on row level security before going live and add policies for your auth model.
alter table users enable row level security;
alter table groups enable row level security;
alter table group_members enable row level security;
alter table payments enable row level security;
