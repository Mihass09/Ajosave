import type { Status } from '@/lib/data'

const styles: Record<Status, string> = {
  Paid: 'bg-green-100 text-green-900',
  Due: 'bg-amber-100 text-amber-900',
  Pending: 'bg-slate-100 text-slate-700',
}

export default function StatusTag({ status }: { status: Status }) {
  return <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${styles[status]}`}>{status}</span>
}
