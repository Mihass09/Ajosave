'use client'
import Link from 'next/link'
import { useState } from 'react'
import { FEE, naira } from '@/lib/data'

type Method = 'paystack' | 'stripe'
const methods: { id: Method; name: string; note: string }[] = [
  { id: 'paystack', name: 'Paystack', note: 'Card, bank transfer, USSD' },
  { id: 'stripe', name: 'Stripe', note: 'International cards' },
]

export default function PayForm({ groupId, groupName, amount }: { groupId: string; groupName: string; amount: number }) {
  const [method, setMethod] = useState<Method>('paystack')
  const [state, setState] = useState<'idle' | 'loading' | 'done'>('idle')
  const [error, setError] = useState('')
  const total = amount + FEE

  async function pay() {
    setState('loading'); setError('')
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groupId, method }),
      })
      const j = await res.json()
      if (!res.ok || !j.url) throw new Error(j.error ?? 'Could not start checkout')
      window.location.href = j.url
    } catch (e: any) {
      setError(e.message); setState('idle')
    }
  }

  return (
    <div className="px-5 pb-10 pt-6">
      <Link href={`/groups/${groupId}`} className="text-sm font-medium text-slate-500">Back</Link>
      <h1 className="mt-3 text-2xl font-bold tracking-tight">Confirm payment</h1>
      <p className="text-slate-500">Contribution to {groupName}</p>

      <section className="mt-6 rounded-[28px] bg-brand-soft p-6">
        <dl className="space-y-3">
          <div className="flex justify-between"><dt className="text-slate-600">Contribution</dt><dd className="font-semibold">{naira(amount)}</dd></div>
          <div className="flex justify-between"><dt className="text-slate-600">Service fee</dt><dd className="font-semibold">{naira(FEE)}</dd></div>
          <div className="flex justify-between border-t border-green-200 pt-4 text-lg">
            <dt className="font-bold">Total</dt><dd className="font-extrabold text-brand-ink">{naira(total)}</dd>
          </div>
        </dl>
      </section>

      <fieldset className="mt-8">
        <legend className="text-lg font-bold">Pay with</legend>
        <div className="mt-3 space-y-3">
          {methods.map((m) => (
            <label key={m.id} className={`flex cursor-pointer items-center gap-4 rounded-2xl border-2 p-4 ${method === m.id ? 'border-brand bg-brand-soft' : 'border-slate-100'}`}>
              <input type="radio" name="method" className="sr-only" checked={method === m.id} onChange={() => setMethod(m.id)} />
              <span className={`grid h-6 w-6 place-items-center rounded-full border-2 ${method === m.id ? 'border-brand' : 'border-slate-300'}`}>
                {method === m.id && <span className="h-3 w-3 rounded-full bg-brand" />}
              </span>
              <span>
                <span className="block font-semibold">{m.name}</span>
                <span className="block text-sm text-slate-500">{m.note}</span>
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      {error && <p className="mt-4 text-sm font-medium text-red-600">{error}</p>}
      <button onClick={pay} disabled={state === 'loading'} className="mt-8 w-full rounded-2xl bg-brand py-4 text-base font-bold text-brand-ink disabled:opacity-60">
        {state === 'loading' ? 'Processing…' : `Pay ${naira(total)} with ${method === 'paystack' ? 'Paystack' : 'Stripe'}`}
      </button>
    </div>
  )
}
