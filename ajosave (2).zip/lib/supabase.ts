import { createClient } from '@supabase/supabase-js'

const url = process.env.NEXT_PUBLIC_SUPABASE_URL
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

// Server-only client (bypasses RLS). Never import this in a client component.
// null when env vars are missing, so the app falls back to mock data.
export const db = url && serviceKey ? createClient(url, serviceKey, { auth: { persistSession: false } }) : null
