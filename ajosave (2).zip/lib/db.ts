import { db } from './supabase'
import { groups as mockGroups, members as mockMembers, getGroup as mockGet, type Group, type Status } from './data'

type Member = { name: string; status: Status; lastPaid: string }

const fmt = (d?: string | null) => (d ? new Date(d).toLocaleDateString('en-NG', { month: 'short', day: 'numeric' }) : 'Not yet')
const sum = (rows: { amount: number }[] | null) => (rows ?? []).reduce((s, r) => s + Number(r.amount), 0)

const toGroup = (g: any, saved: number, nextPayer = 'Nobody due'): Group => ({
  id: g.id, name: g.name, target: Number(g.target_amount), saved,
  contribution: Number(g.contribution_amount), members: g.members_count,
  nextDue: g.next_due ? fmt(g.next_due) : 'Not set', status: 'Active', nextPayer,
})

async function dbGroups(): Promise<Group[]> {
  if (!db) return mockGroups
  const [{ data: gs }, { data: ps }] = await Promise.all([
    db.from('groups').select('*').order('next_due'),
    db.from('payments').select('group_id, amount'),
  ])
  return (gs ?? []).map((g) => toGroup(g, sum((ps ?? []).filter((p) => p.group_id === g.id))))
}

async function dbDetail(id: string): Promise<{ group: Group; members: Member[] } | null> {
  if (!db) {
    const g = mockGet(id)
    return g ? { group: g, members: mockMembers[id] ?? [] } : null
  }
  const { data: g } = await db.from('groups').select('*').eq('id', id).maybeSingle()
  if (!g) return null
  const [{ data: ps }, { data: ms }] = await Promise.all([
    db.from('payments').select('amount').eq('group_id', id),
    db.from('group_members').select('status, last_paid, users(name)').eq('group_id', id),
  ])
  const members: Member[] = (ms ?? []).map((m: any) => ({
    name: (Array.isArray(m.users) ? m.users[0]?.name : m.users?.name) ?? 'Member',
    status: m.status, lastPaid: fmt(m.last_paid),
  }))
  const next = members.find((m) => m.status === 'Due') ?? members.find((m) => m.status === 'Pending')
  return { group: toGroup(g, sum(ps), next?.name), members }
}

// Placeholder until you add Supabase Auth: uses the first user in the table.
async function dbUser(): Promise<{ id: string; name: string; email: string }> {
  if (!db) return { id: 'demo', name: 'Amina', email: 'amina@example.com' }
  const { data } = await db.from('users').select('id, name, email').order('id').limit(1).single()
  if (!data) throw new Error('No users found. Run supabase/seed.sql.')
  return data as any
}

export async function recordPayment(p: {
  groupId: string; userId: string; amount: number; fee: number; method: 'paystack' | 'stripe'; reference: string
}) {
  if (!db) return
  const { error } = await db.from('payments').upsert(
    { group_id: p.groupId, user_id: p.userId, amount: p.amount, fee: p.fee, total: p.amount + p.fee, method: p.method, reference: p.reference },
    { onConflict: 'reference', ignoreDuplicates: true },
  )
  if (error) throw error
  await db.from('group_members')
    .update({ status: 'Paid', last_paid: new Date().toISOString().slice(0, 10) })
    .eq('group_id', p.groupId).eq('user_id', p.userId)
}

const demoUser = { id: 'demo', name: 'Amina', email: 'amina@example.com' }

export async function getGroups(): Promise<Group[]> {
  try {
    const rows = await dbGroups()
    return rows.length ? rows : mockGroups
  } catch (e) {
    console.error('getGroups fell back to mock data:', e)
    return mockGroups
  }
}

export async function getGroupDetail(id: string): Promise<{ group: Group; members: Member[] } | null> {
  try {
    const d = await dbDetail(id)
    if (d) return d
  } catch (e) {
    console.error('getGroupDetail fell back to mock data:', e)
  }
  const g = mockGet(id)
  return g ? { group: g, members: mockMembers[id] ?? [] } : null
}

export async function getCurrentUser(): Promise<{ id: string; name: string; email: string }> {
  try {
    return await dbUser()
  } catch (e) {
    console.error('getCurrentUser fell back to demo user:', e)
    return demoUser
  }
}
