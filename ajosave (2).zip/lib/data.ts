// Mock data. Replace with Supabase queries (see lib/supabase.ts and supabase/schema.sql).
export type Status = 'Paid' | 'Due' | 'Pending'
export type Group = {
  id: string; name: string; target: number; saved: number
  contribution: number; members: number; nextDue: string
  status: 'Active'; nextPayer: string
}

export const FEE = 100
export const user = { name: 'Amina', totalSaved: 1240500 }

export const groups: Group[] = [
  { id: 'family-ajo', name: 'Family Ajo', target: 600000, saved: 520000, contribution: 50000, members: 12, nextDue: 'Oct 15', status: 'Active', nextPayer: 'Tunde Bello' },
  { id: 'freelancers-circle', name: 'Freelancers Circle', target: 500000, saved: 410500, contribution: 25000, members: 8, nextDue: 'Oct 20', status: 'Active', nextPayer: 'Zainab Lawal' },
  { id: 'startup-fund', name: 'Startup Fund', target: 1000000, saved: 310000, contribution: 100000, members: 10, nextDue: 'Nov 1', status: 'Active', nextPayer: 'Emeka Obi' },
]

export const members: Record<string, { name: string; status: Status; lastPaid: string }[]> = {
  'family-ajo': [
    { name: 'Amina Yusuf', status: 'Paid', lastPaid: 'Oct 1' },
    { name: 'Chidi Okafor', status: 'Paid', lastPaid: 'Oct 2' },
    { name: 'Tunde Bello', status: 'Due', lastPaid: 'Sep 15' },
    { name: 'Ngozi Eze', status: 'Pending', lastPaid: 'Sep 16' },
    { name: 'Ibrahim Musa', status: 'Paid', lastPaid: 'Oct 4' },
  ],
  'freelancers-circle': [
    { name: 'Amina Yusuf', status: 'Paid', lastPaid: 'Oct 3' },
    { name: 'Zainab Lawal', status: 'Due', lastPaid: 'Sep 20' },
    { name: 'Segun Adeyemi', status: 'Paid', lastPaid: 'Oct 5' },
    { name: 'Kemi Ade', status: 'Pending', lastPaid: 'Sep 22' },
  ],
  'startup-fund': [
    { name: 'Amina Yusuf', status: 'Paid', lastPaid: 'Oct 1' },
    { name: 'Emeka Obi', status: 'Due', lastPaid: 'Sep 30' },
    { name: 'Halima Garba', status: 'Pending', lastPaid: 'Sep 28' },
    { name: 'Dayo Phillips', status: 'Paid', lastPaid: 'Oct 6' },
  ],
}

export const getGroup = (id: string) => groups.find((g) => g.id === id)
export const naira = (n: number) => '₦' + n.toLocaleString('en-NG')
export const nairaShort = (n: number) => '₦' + (n >= 1_000_000 ? n / 1_000_000 + 'M' : Math.round(n / 1000) + 'k')
export const pct = (g: Group) => Math.round((g.saved / g.target) * 100)
export const initials = (name: string) => name.split(' ').map((p) => p[0]).slice(0, 2).join('')
